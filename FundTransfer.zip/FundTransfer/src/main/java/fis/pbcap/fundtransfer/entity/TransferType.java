package fis.pbcap.fundtransfer.entity;

public enum TransferType {
    CURRENT_ACCOUNT, INTERNAL_TRANSFER, INTERBANK_TRANSFER, SALARY_BATCH_TRANSFER
}