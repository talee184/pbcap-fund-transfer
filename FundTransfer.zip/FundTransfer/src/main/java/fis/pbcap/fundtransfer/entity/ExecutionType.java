package fis.pbcap.fundtransfer.entity;

public enum ExecutionType {
    IMMEDIATE, SCHEDULED
}