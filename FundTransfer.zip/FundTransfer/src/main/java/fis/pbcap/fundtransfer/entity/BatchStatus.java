package fis.pbcap.fundtransfer.entity;

public enum BatchStatus {
    PENDING, APPROVED, REJECTED

}