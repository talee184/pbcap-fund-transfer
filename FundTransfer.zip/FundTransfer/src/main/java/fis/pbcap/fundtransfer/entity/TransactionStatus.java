package fis.pbcap.fundtransfer.entity;

public enum TransactionStatus {
    PENDING, APPROVED, REJECTED
}
